<template>
    <div>
        {{msg}}
    </div>
</template>

<script>
export default {
    name: 'SettingsComponent',
    data() {
        return {
            msg: 'Settings page'
        }
    }
}
</script>